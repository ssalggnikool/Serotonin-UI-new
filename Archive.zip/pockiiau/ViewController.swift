//
//  ViewController.swift
//  pockiiau
//
//  Created by samiiau on 2/27/23.
//  Copyright © 2023 samiiau. All rights reserved.
//

import UIKit
import Darwin

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    // Viewtable options
    var tableData = [["Sileo", "Zebra"], ["Restore Rootfs"]]
    let sectionTitles = ["Managers", "Miscellaneous"]
    var switchStates = [[Bool]]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Navigation titles
            navigationItem.title = "pockiiau"
        let actionsButton = UIBarButtonItem(title: "Actions", style: .plain, target: self, action: #selector(actionsTapped))
        let installButton = UIBarButtonItem(title: "Install", style: .plain, target: self, action: #selector(installTapped))
            navigationItem.leftBarButtonItem = actionsButton
            navigationItem.rightBarButtonItem = installButton
        navigationController?.navigationBar.prefersLargeTitles = true
        let tableView = UITableView(frame: view.bounds, style: .insetGrouped)
            tableView.delegate = self
            tableView.dataSource = self
            view.addSubview(tableView)
        
        // Icon next to the quote
        let headerView = UIView(frame: CGRect(x: 0, y: 0, width: view.frame.width, height: 40))
            headerView.backgroundColor = .clear

        let imageView = UIImageView(image: UIImage(named: "AppIcon"))
            imageView.contentMode = .scaleAspectFit
            imageView.frame = CGRect(x: 20, y: 0, width: 50, height: 50)
            headerView.addSubview(imageView)

        // Quote
        let label = UILabel(frame: CGRect(x: imageView.frame.maxX + 20, y: 0, width: headerView.frame.width - imageView.frame.maxX - 50, height: 0))
        if FileManager.default.fileExists(atPath: "/.bootstrapped_electra") || FileManager.default.fileExists(atPath: "/.installed_unc0ver") || FileManager.default.fileExists(atPath: "/.mount_rw") {
                label.text = "\"We will defy this world with a power from beyond.\""
            } else {
                label.text = "\"Some say a few are chosen and the rest are dregs, but I say we humans have our humanity.\""
            }
            label.numberOfLines = 0
            label.font = UIFont.boldSystemFont(ofSize: 12)
            label.sizeToFit()
            label.center.y = headerView.center.y + 5
            label.frame.origin.x = imageView.frame.maxX + 20

            headerView.addSubview(label)
            headerView.addSubview(imageView)
            headerView.center.x = view.center.x
            tableView.tableHeaderView = headerView
            tableView.contentInset = UIEdgeInsets(top: 40, left: 0, bottom: 0, right: 0)
            tableView.translatesAutoresizingMaskIntoConstraints = false
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return sectionTitles.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tableData[section].count
    }
    
    
    // MARK: - Viewtable for Cydia/Zebra/Restore Rootfs cells
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        let cell = UITableViewCell(style: .subtitle, reuseIdentifier: nil)
            cell.textLabel?.text = tableData[indexPath.section][indexPath.row]
        
        if tableData[indexPath.section][indexPath.row] == "Restore Rootfs" {
        //    if FileManager.default.fileExists(atPath: "/.bootstrapped_electra") || FileManager.default.fileExists(atPath: "/.installed_unc0ver") || FileManager.default.fileExists(atPath: "/.mount_rw") {
        //            cell.isHidden = false
        //            cell.isUserInteractionEnabled = true
        //            cell.accessoryType = .disclosureIndicator
        //            cell.textLabel?.textColor = .systemRed
        //        } else {
                    cell.isUserInteractionEnabled = false
                    cell.accessoryType = .disclosureIndicator
                    cell.textLabel?.textColor = .gray
                    cell.selectionStyle = .none
        //        }
        } else if tableData[indexPath.section][indexPath.row] == "Sileo" || tableData[indexPath.section][indexPath.row] == "Zebra" {
            if tableData[indexPath.section][indexPath.row] == "Sileo" {
                let originalImage = UIImage(named: "Sileo_logo")
                let resizedImage = UIGraphicsImageRenderer(size: CGSize(width: 30, height: 30)).image { _ in
                    originalImage?.draw(in: CGRect(x: 0, y: 0, width: 30, height: 30))
                }
                    cell.imageView?.image = resizedImage
            } else if tableData[indexPath.section][indexPath.row] == "Zebra" {
                let originalImage = UIImage(named: "Zebra_logo")
                let resizedImage = UIGraphicsImageRenderer(size: CGSize(width: 30, height: 30)).image { _ in
                    originalImage?.draw(in: CGRect(x: 0, y: 0, width: 30, height: 30))
                }
                    cell.imageView?.image = resizedImage
            }
            let testSwitch = UISwitch()
                testSwitch.isOn = false
                testSwitch.isEnabled = true
                cell.accessoryView = testSwitch
            if tableData[indexPath.section][indexPath.row] == "Revert Jailbreak" {
                cell.selectionStyle = .default
            } else {
                cell.selectionStyle = .none
            }
            
        }
        
        return cell
    }
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return sectionTitles[section]
    }
    
    func tableView(_ tableView: UITableView, titleForFooterInSection section: Int) -> String? {
        var installed = ""
        if FileManager.default.fileExists(atPath: "/.bootstrapped_electra") || FileManager.default.fileExists(atPath: "/.installed_unc0ver") || FileManager.default.fileExists(atPath: "/.mount_rw") {
            installed = "• Installed"
        }
        if section == tableData.count - 1 {
            let systemVersion = UIDevice.current.systemVersion
            return "pockiiau 1.0 • iOS \(systemVersion) \(installed)"
        }
        return nil
    }
    
    
    // MARK: - Actions action + actions for alertController
    
    @objc func actionsTapped() {
        let alertController = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
        
        let option1Action = UIAlertAction(title: "Respring", style: .default) { (_) in
            ntspawn(command: "/usr/bin/killall", arguments: ["SpringBoard"])
        }
        let option2Action = UIAlertAction(title: "Userspace Reboot", style: .default) { (_) in
            // spawn(command: "/bin/launchctl", arguments: ["reboot", "userspace"])
            restoreRootfs()
        }
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel) { (_) in
        }
        alertController.addAction(option1Action)
        alertController.addAction(option2Action)
        alertController.addAction(cancelAction)
        
        present(alertController, animated: true, completion: nil)
    }
    // MARK: - Recognize if switches are togged + install action (WIP)
    
    @objc func installTapped() {
        let alertController = showAlert()
        var cydiaSwitch = false
        var zebraSwitch = false

        if let tableView = view.subviews.first(where: { $0 is UITableView }) as? UITableView {
            for section in 0..<tableView.numberOfSections {
                for row in 0..<tableView.numberOfRows(inSection: section) {
                    let indexPath = IndexPath(row: row, section: section)
                    if let cell = tableView.cellForRow(at: indexPath),
                        let switchView = cell.accessoryView as? UISwitch
                    {
                        if tableData[indexPath.section][indexPath.row] == "Sileo" {
                            cydiaSwitch = switchView.isOn
                        } else if tableData[indexPath.section][indexPath.row] == "Zebra" {
                            zebraSwitch = switchView.isOn
                        }
                    }
                }
            }
        }

        let loadingAlert = UIAlertController(title: nil, message: "Installing...", preferredStyle: .alert)
        let loadingIndicator = UIActivityIndicatorView(frame: CGRect(x: 10, y: 5, width: 50, height: 50))
        loadingIndicator.hidesWhenStopped = true
        loadingIndicator.startAnimating()

        loadingAlert.view.addSubview(loadingIndicator)

        present(loadingAlert, animated: true) {
            DispatchQueue.global(qos: .userInitiated).async {
                sleep(1)
                print("stage 1")
                sleep(1)
                print("stage 2")
                sleep(1)
                print("stage 3")
                if zebraSwitch == true {
                    print("Zebra")
                }
                sleep(1)
                if cydiaSwitch == true {
                    print("Sileo")
                }
                print("stage 4")
                sleep(1)
                DispatchQueue.main.async {
                    loadingAlert.dismiss(animated: true) {
                        let delayTime = DispatchTime.now() + 0.2
                        DispatchQueue.main.asyncAfter(deadline: delayTime) {
                            self.present(alertController, animated: true)
                        }
                    }
                }
            }
        }

        print("Sileo switch is on: \(cydiaSwitch)")
        print("Zebra switch is on: \(zebraSwitch)")
    }
}
