//
//  LogOutputView.swift
//  pockiiau
//
//  Created by samiiau on 2/28/23.
//  Copyright © 2023 samiiau. All rights reserved.
//

import Foundation
import UIKit

class LogOutputView: UITextView {
    func appendMessage(_ message: String) {
        self.text.append("\(message)\n")
        self.textColor = .black
    }
}
